<?php
require_once 'functions/utils.php';

$token = preparePrint(['test'=>'test'],'test');

echo $token;
?>